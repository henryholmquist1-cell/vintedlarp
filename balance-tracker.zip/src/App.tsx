/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  ArrowLeft, 
  Settings, 
  Info, 
  Landmark, 
  ShoppingCart, 
  Heart, 
  ChevronRight, 
  Home, 
  Search, 
  PlusCircle, 
  Mail, 
  User 
} from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="flex flex-col min-h-screen bg-black text-white font-sans">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-4 bg-[#121212]">
        <button className="p-1 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-lg font-medium">Balance</h1>
        <button className="p-1 hover:bg-white/10 rounded-full transition-colors">
          <Settings size={24} />
        </button>
      </header>

      <main className="flex-1 overflow-y-auto pb-20">
        {/* Pending Balance */}
        <div className="flex items-center justify-between px-4 py-6 bg-[#121212] border-b border-white/5">
          <span className="text-gray-400 text-base">Pending balance</span>
          <div className="flex items-center gap-2">
            <span className="text-gray-400 text-base">SEK 0.00</span>
            <Info size={20} className="text-gray-400" />
          </div>
        </div>

        {/* Main Balance Section */}
        <div className="flex flex-col items-center py-12 bg-[#121212]">
          <h2 className="text-[40px] font-bold tracking-tight mb-1">SEK 439.00</h2>
          <p className="text-gray-400 text-sm mb-10">Available balance</p>

          <div className="flex justify-center gap-12 w-full px-4">
            <div className="flex flex-col items-center gap-3 group cursor-pointer">
              <div className="w-14 h-14 rounded-full bg-[#262626] flex items-center justify-center group-hover:bg-[#333333] transition-colors">
                <Landmark size={24} />
              </div>
              <span className="text-xs font-medium">Withdraw</span>
            </div>
            <div className="flex flex-col items-center gap-3 group cursor-pointer">
              <div className="w-14 h-14 rounded-full bg-[#262626] flex items-center justify-center group-hover:bg-[#333333] transition-colors">
                <ShoppingCart size={24} />
              </div>
              <span className="text-xs font-medium">Shop</span>
            </div>
            <div className="flex flex-col items-center gap-3 group cursor-pointer">
              <div className="w-14 h-14 rounded-full bg-[#262626] flex items-center justify-center group-hover:bg-[#333333] transition-colors">
                <Heart size={24} />
              </div>
              <span className="text-xs font-medium">Donate</span>
            </div>
          </div>
        </div>

        {/* Spacer */}
        <div className="h-2 bg-black"></div>

        {/* Starting Balance */}
        <div className="px-4 py-5 bg-[#121212] flex items-center justify-between border-b border-white/5">
          <div>
            <h3 className="text-base font-medium">Starting balance</h3>
            <p className="text-gray-400 text-sm">Apr 1, 2026</p>
          </div>
          <span className="text-gray-400 text-base">SEK 439.00</span>
        </div>

        {/* Spacer */}
        <div className="h-2 bg-black"></div>

        {/* History */}
        <button className="w-full px-4 py-5 bg-[#121212] flex items-center justify-between hover:bg-white/5 transition-colors">
          <span className="text-base font-medium">History</span>
          <ChevronRight size={20} className="text-gray-400" />
        </button>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-[#121212] border-t border-white/5 px-6 py-3 flex items-center justify-between">
        <div className="flex flex-col items-center gap-1">
          <Home size={24} className="text-gray-400" />
          <span className="text-[10px] text-gray-400">Home</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <Search size={24} className="text-gray-400" />
          <span className="text-[10px] text-gray-400">Search</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <PlusCircle size={24} className="text-gray-400" />
          <span className="text-[10px] text-gray-400">Sell</span>
        </div>
        <div className="flex flex-col items-center gap-1 relative">
          <Mail size={24} className="text-gray-400" />
          <div className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full border border-[#121212]"></div>
          <span className="text-[10px] text-gray-400">Inbox</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <User size={24} className="text-teal-400" />
          <span className="text-[10px] text-teal-400">Profile</span>
        </div>
      </nav>
    </div>
  );
}

